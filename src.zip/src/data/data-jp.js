(function(window){
	
	'use strict';

	window.cityHotelMap = {
		'tokyo': {
			city: 'Tokyo',
			id: 'tokyo',
			hotels: [
				{
					name: 'ホテルマイステイズプレミア赤坂',
					address: '2-17-54 Akasaka, Minato-ku, Tokyo 107-0052 Japan',
					img: 'HOTEL-MYSTAYS-PREMIER-Akasaka.jpg',
					id: '153298'
				},
				{
					name: 'ホテルマイステイズプレミア浜松町',
					address: 'Tokyo, Tokyo-ikebukuro/ Shinjuku, JP13123',
					img: 'HOTEL-MYSTAYS-PREMIER-Hamamatsucho.jpg',
					id: '716'
				},
				{
					name: 'HOTEL MYSTAYS PREMIER Omori',
					address: 'Tokyo, Tokyo-ikebukuro/ Shinjuku, JPsdfs',
					img: 'HOTEL-MYSTAYS-PREMIER-Omori.jpg',
					id: '715'
				},
				{
					name: 'HOTEL MYSTAYS Asakusa',
					address: '',
					img: 'HOTEL-MYSTAYS-Asakusa.jpg',
					id: '28096'
				},
				{
					name: 'HOTEL MYSTAYS Asakusa bashi',
					address: '',
					img: 'HOTEL-MYSTAYS-Asakusabashi.jpg',
					id: '80713'
				},
				{
					name: 'HOTEL MYSTAYS Gotanda',
					address: '',
					img: 'HOTEL-MYSTAYS-Gotanda.jpg',
					id: '28093'
				},
				{
					name: 'HOTEL MYSTAYS Gotanda Station',
					address: '',
					img: 'HOTEL-MYSTAYS-Gotanda-Station.jpg',
					id: '149010'
				},
				{
					name: 'HOTEL MYSTAYS Hamamatsucho',
					address: '',
					img: 'HOTEL-MYSTAYS-Hamamatsucho.jpg',
					id: '73984'
				},
				{
					name: 'HOTEL MYSTAYS Haneda',
					address: '',
					img: 'HOTEL-MYSTAYS-Haneda.jpg',
					id: '147074'
				},
				{
					name: 'HOTEL MYSTAYS Higashi Ikebukuroa',
					address: '',
					img: 'HOTEL-MYSTAYS-Higashi-Ikebukuro.jpg',
					id: '17703'
				},
				{
					name: 'HOTEL MYSTAYS Kamata',
					address: '2-17-54 Akasaka, Minato-ku, Tokyo 107-0052 Japan',
					img: 'HOTEL-MYSTAYS-Kamata.jpg',
					id: '74696'
				},
				{
					name: 'HOTEL MYSTAYS Kameido',
					address: 'Tokyo, Tokyo-ikebukuro/ Shinjuku, JP13123',
					img: 'HOTEL-MYSTAYS-Kameido.jpg',
					id: '16330'
				},
				{
					name: 'HOTEL MYSTAYS Kanda',
					address: 'Tokyo, Tokyo-ikebukuro/ Shinjuku, JPsdfs',
					img: 'HOTEL-MYSTAYS-Kanda.jpg',
					id: '41851'
				},
				{
					name: 'HOTEL MYSTAYS Nippori',
					address: '',
					img: 'HOTEL-MYSTAYS-Nippori.jpg',
					id: '28560'
				},
				{
					name: 'HOTEL MYSTAYS Nishi Shinjuku',
					address: '',
					img: 'HOTEL-MYSTAYS-Nishi-Shinjuku.jpg',
					id: '135409'
				},
				{
					name: 'HOTEL MYSTAYS Ochanomizu Conference Center',
					address: '',
					img: 'HOTEL-MYSTAYS-Ochanomizu-Conference-Center.jpg',
					id: '56917'
				},
				{
					name: 'HOTEL MYSTAYS Ueno East',
					address: '',
					img: 'HOTEL-MYSTAYS-Ueno-East.jpg',
					id: '5627'
				},
				{
					name: 'HOTEL MYSTAYS Ueno Inaricho',
					address: '',
					img: 'HOTEL-MYSTAYS-Ueno-Inaricho.jpg',
					id: '28559'
				},
				{
					name: 'HOTEL MYSTAYS Ueno Iriyaguchi',
					address: '',
					img: 'HOTEL-MYSTAYS-Ueno-Iriyaguchi.jpg',
					id: '28894'
				},
				{
					name: 'FLEXSTAY INN Ekoda',
					address: '',
					img: 'FLEXSTAY-INN-Ekoda.jpg',
					id: '20579'
				},
				{
					name: 'FLEXSTAY INN Higashi Jujo',
					address: '2-17-54 Akasaka, Minato-ku, Tokyo 107-0052 Japan',
					img: 'FLEXSTAY-INN-Higashi-Jujo.jpg',
					id: '28556'
				},
				{
					name: 'FLEXSTAY INN Iidabashi',
					address: 'Tokyo, Tokyo-ikebukuro/ Shinjuku, JP13123',
					img: 'FLEXSTAY-INN-Iidabashi.jpg',
					id: '28095'
				},
				{
					name: 'FLEXSTAY INN Kiyosumi Shirakawa',
					address: 'Tokyo, Tokyo-ikebukuro/ Shinjuku, JPsdfs',
					img: 'FLEXSTAY-INN-Kiyosumi-Shirakawa.jpg',
					id: '28558'
				},
				{
					name: 'FLEXSTAY INN Nakanobu',
					address: '',
					img: 'FLEXSTAY-INN-Nakanobu.jpg',
					id: '28555'
				},
				{
					name: 'FLEXSTAY INN Shinagawa',
					address: '',
					img: 'FLEXSTAY-INN-Shinagawa.jpg',
					id: '28554'
				},
				{
					name: 'FLEXSTAY INN Shirogane',
					address: '',
					img: 'FLEXSTAY-INN-Shirogane.jpg',
					id: '27747'
				},
				{
					name: 'FLEXSTAY INN Sugamo',
					address: '',
					img: 'FLEXSTAY-INN-Sugamo.jpg',
					id: '28094'
				},
				{
					name: 'FLEXSTAY INN Tokiwadai',
					address: '',
					img: 'FLEXSTAY-INN-Tokiwadai.jpg',
					id: '28557'
				},
				{
					name: 'MyCUBE by MYSTAYS Asakusa Kuramae',
					address: '',
					img: 'MyCUBE-by-MYSTAYS-Asakusa-Kuramae.jpg',
					id: '151373'
				}
			]
		},
		'kyoto':{
			city: 'Kyoto',
			id: 'kyoto',
			hotels: [
				{
					name: 'HOTEL MYSTAYS Kyoto Shijo',
					address: '',
					img: 'HOTEL-MYSTAYS-Kyoto-Shijo.jpg',
					id: '68555'
				}
			]
		},
		'osaka':{
			city: 'Osaka',
			id: 'osaka',
			hotels: [
				{
					name: 'HOTEL MYSTAYS Midosuji Honmachi',
					address: '',
					img: 'HOTEL-MYSTAYS-Midosuji-Honmachi.jpg',
					id: '164552'
				},
				{
					name: 'HOTEL MYSTAYS Otemae',
					address: '',
					img: 'HOTEL-MYSTAYS-Otemae.jpg',
					id: '19987'
				},
				{
					name: 'HOTEL MYSTAYS Sakaisuji Honmachi',
					address: '',
					img: 'HOTEL-MYSTAYS-Sakaisuji-Honmachi.jpg',
					id: '72026'
				},
				{
					name: 'HOTEL MYSTAYS Shinsaibashi',
					address: '',
					img: 'HOTEL-MYSTAYS-Shinsaibashi.jpg',
					id: '17986'
				},
				{
					name: 'HOTEL MYSTAYS Shinsaibashi East',
					address: '',
					img: 'HOTEL-MYSTAYS-Shinsaibashi-East.jpg',
					id: '147707'
				},
				{
					name: 'HOTEL MYSTAYS Shin Osaka Conference Center',
					address: '',
					img: 'HOTEL-MYSTAYS-Shin-Osaka-Conference-Center.jpg',
					id: '552'
				}
			]
		},
		'kanazawa':{
			city: 'Kanazawa',
			id: 'kanazawa',
			hotels: [
				{
					name: 'HOTEL MYSTAYS PREMIER Kanazawa',
					address: '',
					img: 'HOTEL-MYSTAYS-PREMIER-Kanazawa.jpg',
					id: '147158'
				},
				{
					name: 'HOTEL MYSTAYS Kanazawa Castle',
					address: '',
					img: 'HOTEL-MYSTAYS-Kanazawa-Castle.jpg',
					id: '175'
				}
			]
		},
		'maihama-urayasu':{
			city: 'Maihama-urayasu',
			id: 'maihama-urayasu',
			hotels: [
				{
					name: 'HOTEL MYSTAYS Maihama',
					address: '',
					img: 'HOTEL-MYSTAYS-Maihama.jpg',
					id: '39203'
				},
				{
					name: 'MYSTAYS Shin Urayasu Conference Center',
					address: '',
					img: 'MYSTAYS-Shin-Urayasu-Conference-Center.jpg',
					id: '76849'
				},
				{
					name: 'FLEXSTAY INN Shin Urayasu',
					address: '',
					img: 'FLEXSTAY-INN-Shin-Urayasu.jpg',
					id: '30925'
				}
			]
		},
		'tachikawa':{
			city: 'Tachikawa',
			id: 'tachikawa',
			hotels: [
				{
					name: 'HOTEL MYSTAYS Tachikawa',
					address: '',
					img: 'HOTEL-MYSTAYS-Tachikawa.jpg',
					id: '18818'
				}
			]
		},
		'kawasaki':{
			city: 'Kawasaki',
			id: 'kawasaki',
			hotels: [
				{
					name: 'FLEXSTAY INN Kawasaki Kaizuka',
					address: '',
					img: 'FLEXSTAY-INN-Kawasaki-Kaizuka.jpg',
					id: '28895'
				},
				{
					name: 'FLEXSTAY INN Kawasaki Ogawacho',
					address: '',
					img: 'FLEXSTAY-INN-Ogawacho.jpg',
					id: '28896'
				},
				{
					name: 'FLEXSTAY INN Tamagawa',
					address: '',
					img: 'FLEXSTAY-INN-Tamagawa.jpg',
					id: '28900'
				}
			]
		},
		'yokohama':{
			city: 'Yokohama',
			id: 'yokohama',
			hotels: [
				{
					name: 'HOTEL MYSTAYS Yokohama',
					address: '',
					img: 'HOTEL-MYSTAYS-Yokohama.jpg',
					id: '50196'
				},
				{
					name: 'HOTEL MYSTAYS Yokohama Kannai',
					address: '',
					img: 'HOTEL-MYSTAYS-Yokohama-Kannai.jpg',
					id: '153564'
				},
				{
					name: 'FLEXSTAY INN Sakuragicho',
					address: '',
					img: 'FLEXSTAY-INN-Sakuragicho.jpg',
					id: '31476'
				}
			]
		},
		'chiba':{
			city: 'Chiba',
			id: 'chiba',
			hotels: [
				{
					name: 'Shirahama Ocean Resort',
					address: '',
					img: 'Shirahama-Ocean-Resort.jpg',
					id: '9662'
				}
			]
		},
		'tochigi':{
			city: 'Tochigi',
			id: 'tochigi',
			hotels: [
				{
					name: 'HOTEL MYSTAYS Utsunomiya',
					address: '',
					img: 'HOTEL-MYSTAYS-Utsunomiya.jpg',
					id: '67045'
				},
				{
					name: 'Hotel Épinard Nasu',
					address: '',
					img: 'Hotel-epinard-Nasu.jpg',
					id: '7335'
				}
			]
		},
		'hokkaido':{
			city: 'Hokkaido',
			id: 'hokkaido',
			hotels: [
				{
					name: 'HOTEL MYSTAYS PREMIER Sapporo Park',
					address: '',
					img: 'HOTEL-MYSTAYS-PREMIER-Sapporo-Park.jpg',
					id: '5903'
				},
				{
					name: 'HOTEL MYSTAYS Sapporo Aspen',
					address: '',
					img: 'HOTEL-MYSTAYS-Sapporo-Aspen.jpg',
					id: '625'
				},
				{
					name: 'HOTEL MYSTAYS Sapporo Nakajima Park',
					address: '',
					img: 'HOTEL-MYSTAYS-Sapporo-Nakajima-Park.jpg',
					id: '9603'
				},
				{
					name: 'HOTEL MYSTAYS Sapporo Nakajima Park Annex',
					address: '',
					img: 'HOTEL-MYSTAYS-Sapporo-Nakajima-Park-Annex.jpg',
					id: '145361'
				},
				{
					name: 'HOTEL MYSTAYS Sapporo Station',
					address: '',
					img: 'HOTEL-MYSTAYS-Sapporo-Station.jpg',
					id: '68288'
				},
				{
					name: 'ART HOTEL ASAHIKAWA',
					address: '',
					img: 'ART-HOTEL-ASAHIKAWA.jpg',
					id: '224'
				},
				{
					name: 'Hotel Nord Otaru',
					address: '',
					img: 'Hotel-Nord-Otaru.jpg',
					id: '3119'
				},
				{
					name: 'Hotel Sonia Otaru',
					address: '',
					img: 'Hotel-Sonia-Otaru.jpg',
					id: '5170'
				},
				{
					name: 'Hakodate Kokusai Hotel',
					address: '',
					img: 'Hakodate-Kokusai-Hotel.jpg',
					id: '1341'
				}
			]
		},
		'aomori':{
			city: 'Aomori',
			id: 'aomori',
			hotels: [
				{
					name: 'ART HOTEL HIROSAKI CITY',
					address: '',
					img: 'ART-HOTEL-HIROSAKI-CITY.jpg',
					id: '504'
				}
			]
		},
		'yamanashi':{
			city: 'Yamanashi',
			id: 'yamanashi',
			hotels: [
				{
					name: 'HOTEL MYSTAYS Fuji',
					address: '',
					img: 'HOTEL-MYSTAYS-Fuji.jpg',
					id: '158471'
				}
			]
		},
		'nagoya':{
			city: 'Nagoya',
			id: 'nagoya',
			hotels: [
				{
					name: 'HOTEL MYSTAYS Nagoya Sakae',
					address: '',
					img: 'HOTEL-MYSTAYS-Nagoya-Sakae.jpg',
					id: '4758'
				}
			]
		},
		'niigata':{
			city: 'Niigata',
			id: 'niigata',
			hotels: [
				{
					name: 'ART HOTEL NIIGATA STATION',
					address: '',
					img: 'ARTHOTEL-NIIGATA-STATION.jpg',
					id: '67938'
				},
				{
					name: 'ART HOTEL JOETSU',
					address: '',
					img: 'ART-HOTEL-JOETSU.jpg',
					id: '1033'
				}
			]
		},
		'kagawa':{
			city: 'Kagawa',
			id: 'kagawa',
			hotels: [
				{
					name: 'Resort Hotel Olivean Shodoshima',
					address: '',
					img: 'Resort-Hotel-Olivean-Shodoshima.jpg',
					id: '7592'
				}
			]
		},
		'ehime':{
			city: 'Ehime',
			id: 'ehime',
			hotels: [
				{
					name: 'HOTEL MYSTAYS Matsuyama',
					address: '',
					img: 'HOTEL-MYSTAYS-Matsuyama.jpg',
					id: '6276'
				}
			]
		},
		'fukuoka':{
			city: 'Fukuoka',
			id: 'fukuoka',
			hotels: [
				{
					name: 'HOTEL MYSTAYS Fukuoka Tenjin Minami',
					address: '',
					img: 'HOTEL-MYSTAYS-Fukuoka-Tenjin-Minami.jpg',
					id: '70215'
				},
				{
					name: 'HOTEL MYSTAYS Fukuoka Tenjin',
					address: '',
					img: 'HOTEL-MYSTAYS-Fukuoka-Tenjin.jpg',
					id: '72791'
				}
			]
		},
		'oita':{
			city: 'Oita',
			id: 'oita',
			hotels: [
				{
					name: 'HOTEL MYSTAYS Oita',
					address: '',
					img: 'HOTEL-MYSTAYS-Oita.jpg',
					id: '67983'
				},
				{
					name: 'Beppu Kamenoi Hotel',
					address: '',
					img: 'Beppu-Kamenoi-Hotel.jpg',
					id: '4807'
				}
			]
		},
		'okinawa':{
			city: 'Okinawa',
			id: 'okinawa',
			hotels: [
				{
					name: 'ART HOTEL ISHIGAKIJIMA',
					address: '',
					img: 'ART-HOTEL-ISHIGAKIJIMA.jpg',
					id: '2770'
				},
				{
					name: 'Fusaki Resort Village (Ishigaki-jima)',
					address: '',
					img: 'Fusaki-Resort-Village-(Ishigaki-jima).jpg',
					id: '38599'
				}
			]
		}
	};
})(window);